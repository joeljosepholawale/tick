import Discord from 'discord.js'
const { ButtonStyle, TextInputStyle } = Discord

export default {
  PREFIX: '!',
  TOKEN:
    'MMTA5ODU4OTM1OTg2NDgxNTc3Nw.GsFstX.W4rOKFwyOBu-xlz6mXJyBaMqFc8sxtavOrUXUo',
  ACTIVITY: { NAME: 'Ticket Bot', TYPE: 'PLAYING' },
  GUILD_ID: '1098592054143111198',
  TICKET: {
    CHANNEL: '1098596542241308742',
    CATEGORY: '1098598785166364682',
    ARCHIVE_CATEGORY: '1098599209395048448',
    MESSAGE: 'Create a ticket by clicking the button below.',
    STAFF_ROLES: [],
    BUTTONS: [
      {
        STYLE: ButtonStyle.Success,
        LABEL: 'Confirm Ticket',
        EMOTE: '✅',
        ID: 'successTicket',
        DISABLED: false,
      },
      {
        STYLE: ButtonStyle.Secondary,
        LABEL: 'Archive Ticket',
        EMOTE: '🎫',
        ID: 'archiveTicket',
        DISABLED: false,
      },
      {
        STYLE: ButtonStyle.Danger,
        LABEL: 'Delete Ticket',
        EMOTE: '🎟️',
        ID: 'deleteTicket',
        DISABLED: false,
      },
    ],
    QUESTIONS: [
      {
        ID: 'wallet-name',
        LABEL: 'Enter your wallet name',
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 0,
        MAX_LENGTH: 200,
        PLACE_HOLDER: 'e.g Trust',
        REQUIRED: true,
      },
      {
        ID: 'wallet-address',
        LABEL: 'Enter your wallet address',
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 0,
        MAX_LENGTH: 200,
        PLACE_HOLDER: 'e.g 0x5a...',
        REQUIRED: true,
      },
      {
        ID: 'email-address',
        LABEL: 'Enter your email address',
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 0,
        MAX_LENGTH: 200,
        PLACE_HOLDER: 'e.g ...@mail.com',
        REQUIRED: true,
      },
    ],
  },
}
